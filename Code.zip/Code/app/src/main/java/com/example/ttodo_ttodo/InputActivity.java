package com.example.ttodo_ttodo;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;
import java.util.ArrayList;




public class InputActivity extends AppCompatActivity  {
    SQLiteDatabase database;
    EditText editText_name;
    TextView t;

    public long backBtnTime = 0;
    @Override
    public void onBackPressed() { //뒤로가기 버튼 구현
        finish();
        Intent gomain = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(gomain);

    }
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.input);

        editText_name = (EditText) findViewById(R.id.editText_name);

        database = openOrCreateDatabase("DB",  MODE_PRIVATE, null); //open

        editText_name.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String name = editText_name.getText().toString().trim();

                    insertData(name);
                    finish();
                    Intent inputIntent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(inputIntent);
                    return true;
                }
                return false;
            }
        });




    }
    public void insertData(String name) {

        if (database != null) {
            String sql = "insert into todo_table(name, sel) values(?, ?)";
            Object[] params = {name,0};
            database.execSQL(sql, params);
        }


    }


    class TodoAdapter extends BaseAdapter {
        ArrayList<Item> items = new ArrayList<Item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(Item item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            ItemView view = new ItemView(getApplicationContext());

            Item item = items.get(position);
            view.setName(item.getName());
            t = (TextView) view.findViewById(R.id.textView);
            if(item.getSel()) t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            else t.setPaintFlags(t.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);

            return view;
        }
    }

}

