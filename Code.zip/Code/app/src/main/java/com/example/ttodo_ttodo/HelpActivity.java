package com.example.ttodo_ttodo;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HelpActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {
        finish();
        Intent main = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main);

    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_main);
    }
}
