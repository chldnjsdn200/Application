package com.example.ttodo_ttodo;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import static java.sql.DriverManager.println;

public class SearchActivity extends AppCompatActivity {
    SQLiteDatabase database;
    EditText search_task;
    ListView listView;
    TodoAdapter adapter;
    TextView t;
    public long backBtnTime = 0;


    private void createDatabase(String name) {
        println("creating database [" + name + "].");

        try {
            database = openOrCreateDatabase(
                    name,
                    Activity.MODE_PRIVATE,
                    null);

            boolean databaseCreated = true;
            println("database is created.");
        } catch(Exception ex) {
            ex.printStackTrace();
            println("database is not created.");
        }
    }

    private void createTable(String name) {
        println("creating table [" + name + "].");

        database.execSQL("create table if not exists " + name + "("
                + " _id integer PRIMARY KEY autoincrement, "
                + " name text, "
                + " sel integer);" );
        //sel integer

        boolean tableCreated = true;
    }
    /*데이터 조회 -> 리스트에 추가 -> listView.setAdapter(adapter) - 갱신이 안되면;*/
    public  void selectData_false(String x){
        if(database != null){
            String sql = "select _id, name, sel from todo_table where name like '%"+x+"%'";
            Cursor cursor = database.rawQuery(sql, null);

            for( int i = 0; i< cursor.getCount(); i++){
                cursor.moveToNext();//다음 레코드로 넘어간다.
                int pk = cursor.getInt(0);
                String name = cursor.getString(1);
                boolean sel = cursor.getInt(2) > 0;
                adapter.addItem(new Item(pk, name, sel));

            }
            cursor.close();
        }
    }

    /*데이터 조회 -> 리스트에 추가 -> listView.setAdapter(adapter) - 갱신이 안되면;*/
    public  void selectData_true(String x){
        if(database != null){
            String sql = "select _id, name, sel from todo_table where name like '%"+x+"%' and sel = 0";
            Cursor cursor = database.rawQuery(sql, null);

            for( int i = 0; i< cursor.getCount(); i++){
                cursor.moveToNext();//다음 레코드로 넘어간다.
                int pk = cursor.getInt(0);
                String name = cursor.getString(1);
                boolean sel = cursor.getInt(2) > 0;
                adapter.addItem(new Item(pk, name, sel));

            }
            cursor.close();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);


        final Switch switch_button = (Switch) findViewById(R.id.switch_button);
        search_task = (EditText) findViewById(R.id.search_task);

        search_task.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                //Enter key Action
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String name = search_task.getText().toString().trim();
                    adapter.items.clear();
                    if(switch_button.isChecked()) selectData_true(name);
                    else selectData_false(name);
                    adapter.notifyDataSetChanged();
                    //Enter키눌렀을떄 처리
                    return true;
                }
                return false;
            }
        });


        listView = (ListView) findViewById(R.id.listView);

        createDatabase("DB");
        createTable("todo_table");


        adapter = new TodoAdapter();

        listView.setAdapter(adapter);
    }

    class TodoAdapter extends BaseAdapter {
        ArrayList<Item> items = new ArrayList<Item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(Item item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            ItemView view = new ItemView(getApplicationContext());

            Item item = items.get(position);
            view.setName(item.getName());
            t = (TextView) view.findViewById(R.id.textView);
            if(item.getSel()) t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            else t.setPaintFlags(t.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);

            return view;
        }
    }
}


