package com.example.ttodo_ttodo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import static java.sql.DriverManager.println;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    SQLiteDatabase database;
    EditText editText;
    ListView listView;
    TodoAdapter adapter;
    TextView t;
    Animation fab_open, fab_close;
    FloatingActionButton fab_menu, fab_delete, fab_search, fab_add,fab_help;
    Boolean openFlag = false;
    public long backBtnTime = 0;


    @Override
    //뒤로가기 버튼 두번 눌러야 가능하게 구현
    public void onBackPressed() {
        long curTime = System.currentTimeMillis();
        long gapTime = curTime - backBtnTime;

        if(0 <= gapTime && 2000 >= gapTime) {
            super.onBackPressed();
        }
        else {
            backBtnTime = curTime;
            Toast.makeText(this, "한번 더 누르면 종료됩니다.",Toast.LENGTH_SHORT).show();
        }


    }
    //삭제함수
    public void deleteData(String name) {

        if (database != null) {
             String sql = "delete from todo_table WHERE sel = " + 1+";";
            database.execSQL(sql);
        }
    }
    //sel 업데이트
    public int selectUpdate(int pk, boolean sel) {

        ContentValues recordValues = new ContentValues();
        if(sel == true) recordValues.put("sel", 0);
        else  recordValues.put("sel", 1);;

        int rowAffected = database.update("todo_table",
                recordValues,
                "_id = " + pk,
                null);

        return rowAffected;
    }
    //내용 수정
    public void updateText(int pk, String str) {
        String sql = "UPDATE todo_table SET name = '"+ str +"' WHERE _id = "+ pk;
        database.execSQL(sql);
    } //내용 수정 함수
    //데이터 베이스 생성
    private void createDatabase(String name) {
        println("creating database [" + name + "].");

        try {
            database = openOrCreateDatabase(
                    name,
                    Activity.MODE_PRIVATE,
                    null);

            boolean databaseCreated = true;
            println("database is created.");
        } catch(Exception ex) {
            ex.printStackTrace();
            println("database is not created.");
        }
    }
   //테이블 생성
    private void createTable(String name) {
        println("creating table [" + name + "].");

        database.execSQL("create table if not exists " + name + "("
                + " _id integer PRIMARY KEY autoincrement, "
                + " name text, "
                + " sel integer);" );
        //sel integer

        boolean tableCreated = true;
    }
    //데이터 조회
    public  void selectData(){
        //아이템 추가
        if(database != null){
            String sql = "select _id, name, sel from todo_table";
            Cursor cursor = database.rawQuery(sql, null);

            for( int i = 0; i< cursor.getCount(); i++){
                cursor.moveToNext();//다음 레코드로 넘어간다.
                int pk = cursor.getInt(0);
                String name = cursor.getString(1);
                boolean sel = cursor.getInt(2) > 0;
                adapter.addItem(new Item(pk, name, sel));

            }
            cursor.close();
        }
    }
   //플로팅 액션 버튼 애니메이션 구현(메뉴 누를 시 위에 더 생기도록, 기본값 false)
    public void anim() {

        if (openFlag) {
            fab_delete.startAnimation(fab_close);
            fab_add.startAnimation(fab_close);
            fab_search.startAnimation(fab_close);
            fab_help.startAnimation(fab_close);

            fab_delete.setClickable(false);
            fab_add.setClickable(false);
            fab_search.setClickable(false);
            fab_help.setClickable(false);

            openFlag = false;
        } else {
            fab_delete.startAnimation(fab_open);
            fab_add.startAnimation(fab_open);
            fab_search.startAnimation(fab_open);
            fab_help.startAnimation(fab_open);

            fab_delete.setClickable(true);
            fab_add.setClickable(true);
            fab_search.setClickable(true);
            fab_help.setClickable(true);

            openFlag = true;
        }
    }
    @Override
    public void onClick(View v){
        int id = v.getId();

        switch (id) {
            case R.id.fab_menu:
                anim();
                break;
            case R.id.fab_delete:
                anim();
                deleteData("");
                adapter.items.clear();
                selectData();
                adapter.notifyDataSetChanged();
                break;
            case R.id.fab_add:
                anim();
                finish();
                Intent inputIntent = new Intent(getApplicationContext(), InputActivity.class);
                startActivity(inputIntent);
                break;
            case R.id.fab_search:
                anim();
                //finish();
                Intent search = new Intent(getApplicationContext(), SearchActivity.class);
                startActivity(search);
                break;
            case R.id.fab_help:
                anim();
                finish();
                Intent help = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(help);
                break;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fab_close);

        fab_menu = findViewById(R.id.fab_menu);
        fab_delete = findViewById(R.id.fab_delete);
        fab_add = findViewById(R.id.fab_add);
        fab_search = findViewById(R.id.fab_search);
        fab_help = findViewById(R.id.fab_help);

        fab_delete.startAnimation(fab_close);
        fab_delete.setClickable(false);
        fab_add.startAnimation(fab_close);
        fab_add.setClickable(false);
        fab_search.startAnimation(fab_close);
        fab_search.setClickable(false);
        fab_help.startAnimation(fab_close);
        fab_help.setClickable(false);

        fab_menu.setOnClickListener(this);
        fab_delete.setOnClickListener(this);
        fab_add.setOnClickListener(this);
        fab_search.setOnClickListener(this);
        fab_help.setOnClickListener(this);


        listView = (ListView) findViewById(R.id.listView);

        createDatabase("DB");
        createTable("todo_table");


        adapter = new TodoAdapter();

        selectData();

        listView.setAdapter(adapter);

        editText = (EditText) findViewById(R.id.editText);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                //취소선
                Item item = (Item) adapter.getItem(position);
                selectUpdate(item.getPk(), item.getSel());
                adapter.items.clear();
                selectData();
                adapter.notifyDataSetChanged();
            //    Toast.makeText(getApplicationContext(), "선택 : " + item.getName(), Toast.LENGTH_LONG).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                { //수정
                    //@Override
                    final Item item = (Item) adapter.getItem(position);
                    updateText(item.getPk(), item.getName());
                    adapter.items.clear();

                    AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                    ad.setIcon(R.mipmap.ic_luncher);
                    ad.setTitle("뚜두뚜두");
                    ad.setMessage("\n수정 할 내용을 입력하세요.");
                    final EditText et = new EditText(MainActivity.this);
                    et.setText(item.getName());
                    ad.setView(et);

                    ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String name = et.getText().toString().trim();

                            updateText(item.getPk(), name);
                            selectData();
                            adapter.notifyDataSetChanged();

                            dialogInterface.dismiss();
                        }
                    });

                    ad.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            selectData();
                            adapter.notifyDataSetChanged();
                            dialogInterface.dismiss();
                        }
                    });
                    ad.show();
                }
                return true;

            }
        });





    }

    class TodoAdapter extends BaseAdapter {
        ArrayList<Item> items = new ArrayList<Item>();

        @Override
        public int getCount() {
            return items.size();
        }

        public void addItem(Item item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {
            com.example.ttodo_ttodo.ItemView view = new com.example.ttodo_ttodo.ItemView(getApplicationContext());

            Item item = items.get(position);
            view.setName(item.getName());
            t = (TextView) view.findViewById(R.id.textView);
            if(item.getSel()) {
                t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                String strColor = "#808080";
                t.setTextColor(Color.parseColor(strColor));
            }
            else {
                t.setPaintFlags(t.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            }

            return view;








        }
    }
}


