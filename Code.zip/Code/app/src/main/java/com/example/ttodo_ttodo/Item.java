package com.example.ttodo_ttodo;

public class Item {
    int pk;
    String name;
    boolean sel;

   public Item(int pk){
       this.pk = pk;
   }

   public Item(int pk, String name) {
        this.pk = pk;
        this.name = name;
        this.sel = false;
    }

    public Item(int pk, String name, boolean sel) {
        this.pk = pk;
        this.name = name;
        this.sel = sel;
    }


   public int getPk(){
       return pk;
   }

    public void setPk(int pk){
        this.pk = pk;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getSel() {
        return sel;
    }

    public void setSel(boolean sel) {
        this.sel = sel;
    }

}
